package com.ae.intg;

public class Constants {
	// static final String AUTHORIZATION_HEADER_PREFIX = "Basic ";
	// static final String SERVICENOW_URL =
	// "/api/x_aetp_ae500/automationedge_requests?orgCodes=";

	// Integration configuration parameters
	// static final String BASE_URL_KEY = "URL";

	// authentication parameters
	static final String DB_USER_KEY = "User Name";
	static final String DB_PASSWORD_KEY = "Password";
	static final String DB_Port = "Port Number";
	static final String DB_DBNAME = "Database Name";
	// static final String DB_TBName ="Table Name";
	static final String DB_Query = "Query";
	static final String DB_FilePath = "File";

}
